package com.main;
import java.util.Scanner;

public class MainApplication {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserOperations userOperations = new UserOperations();
        AppointmentOperations appointmentOperations = new AppointmentOperations();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add User");
            System.out.println("2. Add Appointment");
            System.out.println("3. View Appointments");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    userOperations.addUser();
                    break;
                case 2:
                    appointmentOperations.addAppointment();
                    break;
                case 3:
                    // Implement view logic
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
