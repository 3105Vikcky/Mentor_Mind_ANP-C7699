package com.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AppointmentOperations {

    public void addAppointment() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO appointment (patientName, patientPhone, patientAge, patientGender, BloodGroup, appt_Date, appt_Time, address, patientEmail, doctorName, doctorPhone, testName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);

            Scanner sc = new Scanner(System.in);

            System.out.println("Enter patient name:");
            String patientName = sc.nextLine();
            
            System.out.println("Enter patient phone:");
            String patientPhone = sc.nextLine();
            
            System.out.println("Enter patientAge: ");
            int patientAge=sc.nextInt();
            
            
            System.out.println("Enter Gender: ");
            String gender
            
            System.out.println("Enter ");
            // ... continue for all fields.

            stmt.setString(1, patientName);
            stmt.setString(2, patientPhone);
            // Set other parameters as per input.

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Appointment added successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Similarly, implement viewAppointment(), updateAppointment(), deleteAppointment().
}
