package com.main;
public class Appointment {
    private int ap_id;
    private String patientName;
    private String patientPhone;
    private int patientAge;
    private String patientGender;
    private String bloodGroup;
    private String apptDate;
    private String apptTime;
    private String address;
    private String patientEmail;
    private String doctorName;
    private String doctorPhone;
    private String testName;

    
    
 // Constructor
    public Appointment(int ap_id, String patientName, String patientPhone, int patientAge, String patientGender, 
                       String bloodGroup, String apptDate, String apptTime, String address, 
                       String patientEmail, String doctorName, String doctorPhone, String testName) {
        this.ap_id = ap_id;
        this.patientName = patientName;
        this.patientPhone = patientPhone;
        this.patientAge = patientAge;
        this.patientGender = patientGender;
        this.bloodGroup = bloodGroup;
        this.apptDate = apptDate;
        this.apptTime = apptTime;
        this.address = address;
        this.patientEmail = patientEmail;
        this.doctorName = doctorName;
        this.doctorPhone = doctorPhone;
        this.testName = testName;
    }

    // Getters
    public int getAp_id() {
        return ap_id;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public String getPatientGender() {
        return patientGender;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public String getApptDate() {
        return apptDate;
    }

    public String getApptTime() {
        return apptTime;
    }

    public String getAddress() {
        return address;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getDoctorPhone() {
        return doctorPhone;
    }

    public String getTestName() {
        return testName;
    }

    // Setters
    public void setAp_id(int ap_id) {
        this.ap_id = ap_id;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public void setApptDate(String apptDate) {
        this.apptDate = apptDate;
    }

    public void setApptTime(String apptTime) {
        this.apptTime = apptTime;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public void setDoctorPhone(String doctorPhone) {
        this.doctorPhone = doctorPhone;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }
}
