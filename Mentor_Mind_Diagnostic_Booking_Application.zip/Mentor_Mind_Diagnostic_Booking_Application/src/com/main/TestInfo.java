package com.main;
public class TestInfo {
    private int t_id;
    private String testName;
    private double price;
    private String testDate;
    private int appointmentId;
    
    
 // Constructor, getters, and setters.
    
	public TestInfo(int t_id, String testName, double price, String testDate, int appointmentId) {
		super();
		this.t_id = t_id;
		this.testName = testName;
		this.price = price;
		this.testDate = testDate;
		this.appointmentId = appointmentId;
	}
	public int getT_id() {
		return t_id;
	}
	public void setT_id(int t_id) {
		this.t_id = t_id;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getTestDate() {
		return testDate;
	}
	public void setTestDate(String testDate) {
		this.testDate = testDate;
	}
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
    
    

    
}

